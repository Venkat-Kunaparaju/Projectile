from sklearn.ensemble import RandomForestClassifier
import numpy as np

file = open('intro.text', 'r')
print(file.read())
print("  ")
char_comp = ['M', 'E', 'B', 'R', 'V']
char_dict = {'M':0, 'E':1, 'B':2, 'R':3, 'V':4}
new_list = []
file = open('char.text', 'r') 
clf = RandomForestClassifier(n_estimators=100, class_weight = 'balanced')
# atomic mass g/mol, electronegativity, boiling point C, atomic radius pm, valence electrons
x = [[1.0079,2.2,-252.87,53,1],[4.0026,0,-268.93,31,2],[6.941,.98,1342,167,1],[9.0122,1.57,2470,112,2],[10.811,2.04,4000,87,3],[12.0107,2.55,4027,67,4],[14.0067,3.04,-195.79,56,5],[15.9994,3.44,-182.9,48,6],[18.9984,3.98,-188.12,42,7],[20.1797,0,-246.08,38,8],[22.9897,.93,883,190,1],[24.305,1.31,1090,145,2],[26.9815,1.61,2519,118,3],[28.0855,1.9,2900,111,4],[30.9738,2.19,280.5,98,5],[32.065,2.58,444.72,87,6],[35.453,3.16,-34.04,79,7],[39.948,0,-185.8,71,8],[39.0983,.82,759,243,1],[40.078,1,1484,194,2],[44.9559,1.36,2830,184,2],[47.867,1.54,3287,176,2],[50.9415,1.63,3407,171,2],[51.9961,1.66,2671,166,1],[54.938,1.55,2061,161,2],[55.845,1.83,2861,156,2],[58.9332,1.88,2927,152,2],[58.6934,1.91,2913,149,2],[63.546,1.9,2562,145,1],[65.39,1.65,907,142,2],[69.723,1.81,2204,136,3],[72.64,2.01,2820,125,4],[74.9216,2.18,614,114,5],[78.96,2.55,685,103,6],[79.904,2.96,59,94,7],[83.8,3,-153.22,87,8],[85.4678,.82,688,265,1],[87.62,.95,1382,219,2],[88.9059,1.22,3345,212,3],[91.224,1.33,4409,206,4]]
y= [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40]
x = np.reshape(x, (40,5))


char = []
answer = ' '
wild = True
print (file.read()) 
print(' ')
print("Enter the first letter of the charactersitics of the elements you DO NOT want to take in account from the list above. Press enter after you have entered the letter. You can keep going and press 1 to stop.*Note the more characterisitics you choose to have, the answer becomes less accurate*.")
w = (0,[])

while (answer != '1'):
	answer = input()
	if answer == '1':
		break
	else:
		answer = answer.upper()
		answer = answer[0]
		char.append(answer)

for i in char_comp:
	if i in char:
		w[1].append(char_dict[i])
x = np.delete(x, w[1], 1)


#x= np.delete(x, row, axis(0 or 1))
predict = []

if 'M' not in char:
	m = int(input("Enter the atomic mass you are looking for: "))
	predict.append(m)
if 'E' not in char:
	e = int(input("Enter the electronegativity you are looking for: "))
	predict.append(e)
if 'B' not in char:
	b = int(input("Enter the boiling point you are looking for: "))
	predict.append(b)
if 'R' not in char:
	r = int(input("Enter the the atomic radius you are looking for: "))
	predict.append(r)
if 'V' not in char:
	v = int(input("Enter the number of valence electrons you are looking for: "))
	predict.append(v)

print('--------------------------------------------------------------------------')
clf.fit(x,y)


if 1 == clf.predict([predict]):
	print('Hydrogen')
if 2 == clf.predict([predict]):
	print('Helium')
if 3 == clf.predict([predict]):
	print('Lithium')
if 4 == clf.predict([predict]):
	print('Beryllium')
if 5 == clf.predict([predict]):
	print('Boron')
if 6 == clf.predict([predict]):
	print('Carbon')
if 7 == clf.predict([predict]):
	print('Nitrogen')
if 8 == clf.predict([predict]):
	print('Oxygen')
if 9 == clf.predict([predict]):
	print('Fluorine')
if 10 == clf.predict([predict]):
	print('Neon')
if 11 == clf.predict([predict]):
	print('Sodium')
if 12 == clf.predict([predict]):
	print('Magnesium')
if 13 == clf.predict([predict]):
	print('Aluminum')
if 14 == clf.predict([predict]):
	print('Silicon')
if 15 == clf.predict([predict]):
	print('Phosphorus')
if 16 == clf.predict([predict]):
	print('Sulfur')
if 17 == clf.predict([predict]):
	print('Chlorine')
if 18 == clf.predict([predict]):
	print('Argon')
if 19 == clf.predict([predict]):
	print('Potassium')
if 20 == clf.predict([predict]):
	print('Calcium')
if 21 == clf.predict([predict]):
	print('Scandium')
if 22 == clf.predict([predict]):
	print('Titanium')
if 23 == clf.predict([predict]):
	print('Vanadium')
if 24 == clf.predict([predict]):
	print('Chromium')
if 25 == clf.predict([predict]):
	print('Maganese')
if 26 == clf.predict([predict]):
	print('Iron')
if 27 == clf.predict([predict]):
	print('Cobalt')
if 28 == clf.predict([predict]):
	print('Nickel')
if 29 == clf.predict([predict]):
	print('Copper')
if 30 == clf.predict([predict]):
	print('Zinc')
if 31 == clf.predict([predict]):
	print('Gallium')
if 32 == clf.predict([predict]):
	print('Germanium')
if 33 == clf.predict([predict]):
	print('Arsenic')
if 34 == clf.predict([predict]):
	print('Selnium')
if 35 == clf.predict([predict]):
	print('Bromine')
if 36 == clf.predict([predict]):
	print('Krypton')
if 37 == clf.predict([predict]):
	print('Rubidium')
if 38 == clf.predict([predict]):
	print('Strontium')
if 39 == clf.predict([predict]):
	print('Yttrium')
if 40 == clf.predict([predict]):
	print('Zirconium')
print(f'Atomic Number: {clf.predict([predict])}')